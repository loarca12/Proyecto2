
package ipc202100312;
/**
 *
 * @author gcifuentes
 */
import views.Menu;


public class Proyecto2 {
  
    public static void main(String[] args) {
        
 
       Menu form1 = new Menu();
       form1.setVisible(true);
       
 
    }
        
    
}
