
package clases;

/**
 *
 * @author gcifuentes
 */
public class editarIMG {
    
}
