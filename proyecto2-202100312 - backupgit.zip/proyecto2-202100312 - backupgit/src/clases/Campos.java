
package clases;
/**
 *
 * @author gcifuentes
 */

public class Campos {
    String usuario;
    String categoria;

    public Campos(String usuario, String categoria) {
        this.usuario = usuario;
        this.categoria = categoria;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
}
