
package clases;
/**
 *
 * @author gcifuentes
 */
import java.util.ArrayList;

public class ListaCampos {
    
    public static ArrayList<Campos> listaRegistro = new ArrayList();
    
    public static String addUsernuevo(String user){
        Campos agregar = new Campos(user,"General");
        listaRegistro.add(agregar);
    
        return "Usuario Agregado";
    
    }
    public static String addCategoria(String user, String categoria){
        Campos agregar = new Campos(user,categoria);
        listaRegistro.add(agregar);
    
        return "categoria fue agregada";
    
    }
    
}

